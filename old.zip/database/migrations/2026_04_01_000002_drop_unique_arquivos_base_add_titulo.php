<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('arquivos_base', function (Blueprint $table) {
            $table->string('titulo')->nullable()->after('tipo');
            $table->string('slug')->nullable()->after('titulo');
        });
    }

    public function down(): void
    {
        Schema::table('arquivos_base', function (Blueprint $table) {
            $table->dropColumn(['titulo', 'slug']);
        });
    }
};
